using System;
using System.Collections.Generic;
using System.Text;
using CookComputing.XmlRpc;

namespace client
{
  public interface IStateName : global::IStateName, IXmlRpcProxy
  {
  }
}
